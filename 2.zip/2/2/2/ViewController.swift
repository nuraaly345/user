//
//  ViewController.swift
//  2
//
//  Created by zalkarbek on 2/10/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

