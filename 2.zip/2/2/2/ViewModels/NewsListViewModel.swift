import Foundation

class NewsListViewModel {
    var articles: [Article] = []
    var isLoading = false
    var error: Error?
    var nextPage: String? = nil // Начинаем с nil, что означает первую страницу

    func fetchNews(completion: @escaping () -> Void) {
        guard !isLoading else { return }
        isLoading = true

        NetworkService.shared.fetchTopHeadlines(nextPage: nextPage) { [weak self] result in
            guard let self = self else { return }
            self.isLoading = false

            switch result {
            case .success(let data):
                self.articles += data.articles
                self.nextPage = data.nextPage // Обновляем значение nextPage
                self.error = nil
                completion()
            case .failure(let error):
                self.error = error
                completion()
            }
        }
    }
}
