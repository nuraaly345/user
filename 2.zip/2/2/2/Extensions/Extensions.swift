//
//  Extensions.swift
//  2
//
//  Created by zalkarbek on 2/10/24.
//

// Extensions/UIImageView+Load.swift

import UIKit

extension UIImageView {
    func load(url: URL) {
        let cache = URLCache.shared
        let request = URLRequest(url: url)

        if let data = cache.cachedResponse(for: request)?.data, let image = UIImage(data: data) {
            self.image = image
            return
        }

        DispatchQueue.global().async {
            if let data = try? Data(contentsOf: url) {
                let response = URLResponse(url: url, mimeType: nil, expectedContentLength: data.count, textEncodingName: nil)
                let cachedData = CachedURLResponse(response: response, data: data)
                cache.storeCachedResponse(cachedData, for: request)
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self.image = image
                    }
                }
            }
        }
    }
}
