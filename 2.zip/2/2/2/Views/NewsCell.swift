import Foundation
import UIKit

class NewsCell: UITableViewCell {
    private let newsImageView = UIImageView()
    private let titleLabel = UILabel()
    private let creatorLabel = UILabel()
    private let dateLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func setupUI() {
        contentView.addSubview(newsImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(creatorLabel)
        contentView.addSubview(dateLabel)

        newsImageView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        creatorLabel.translatesAutoresizingMaskIntoConstraints = false
        dateLabel.translatesAutoresizingMaskIntoConstraints = false

        // Настройка newsImageView
        newsImageView.contentMode = .scaleAspectFill
        newsImageView.clipsToBounds = true

        // Ограничения для newsImageView
        NSLayoutConstraint.activate([
            newsImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            newsImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            newsImageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8),
            newsImageView.widthAnchor.constraint(equalToConstant: 80),
            newsImageView.heightAnchor.constraint(equalToConstant: 80)
        ])

        // Ограничения для titleLabel
        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: newsImageView.trailingAnchor, constant: 8),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8)
        ])

        // Ограничения для creatorLabel
        NSLayoutConstraint.activate([
            creatorLabel.leadingAnchor.constraint(equalTo: newsImageView.trailingAnchor, constant: 8),
            creatorLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            creatorLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4)
        ])

        // Ограничения для dateLabel
        NSLayoutConstraint.activate([
            dateLabel.leadingAnchor.constraint(equalTo: newsImageView.trailingAnchor, constant: 8),
            dateLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            dateLabel.topAnchor.constraint(equalTo: creatorLabel.bottomAnchor, constant: 4),
            dateLabel.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -8)
        ])

        // Настройка шрифтов и цветов
        titleLabel.font = UIFont.boldSystemFont(ofSize: 16)
        titleLabel.numberOfLines = 2

        creatorLabel.font = UIFont.systemFont(ofSize: 14)
        creatorLabel.textColor = .secondaryLabel

        dateLabel.font = UIFont.systemFont(ofSize: 12)
        dateLabel.textColor = .tertiaryLabel
    }

    func configure(with article: Article) {
        titleLabel.text = article.title
        creatorLabel.text = article.creator?.first ?? "Неизвестный автор"
        dateLabel.text = formatDate(article.pubDate)

        if let imageUrlString = article.imageUrl, let imageUrl = URL(string: imageUrlString) {
            newsImageView.load(url: imageUrl)
        } else {
            newsImageView.image = UIImage(systemName: "photo")
        }
    }

    private func formatDate(_ dateString: String?) -> String {
        // Проверяем, что dateString не nil
        guard let dateString = dateString else {
            return ""
        }
        
        // Создаем объект DateFormatter для преобразования строки в дату
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss" // Формат входящей даты, проверьте соответствие вашим данным
        inputFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        // Пытаемся получить объект Date из строки
        if let date = inputFormatter.date(from: dateString) {
            // Создаем второй DateFormatter для преобразования даты в строку нужного формата
            let outputFormatter = DateFormatter()
            outputFormatter.dateStyle = .medium
            outputFormatter.timeStyle = .short
            outputFormatter.timeZone = TimeZone.current
            
            // Получаем строку с форматом даты для отображения
            let formattedDate = outputFormatter.string(from: date)
            return formattedDate
        } else {
            // Если не удалось преобразовать строку в дату, возвращаем оригинальную строку или пустую строку
            return dateString
        }
    }
}

