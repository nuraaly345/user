//
//  FavoritesViewModel.swift
//  2
//
//  Created by zalkarbek on 2/10/24.
//

// ViewModels/FavoritesViewModel.swift

import Foundation

class FavoritesViewModel {
    var articles: [Article] = []

    func loadFavorites() {
        articles = FavoriteManager.shared.getFavorites()
    }

    func removeFavorite(_ article: Article, completion: @escaping () -> Void) {
        FavoriteManager.shared.removeFavorite(article)
        loadFavorites()
        completion()
    }
}
