//
//  NewsDetailViewModel.swift
//  2
//
//  Created by zalkarbek on 2/10/24.
//

// ViewModels/NewsDetailViewModel.swift

import Foundation

class NewsDetailViewModel {
    var article: Article

    init(article: Article) {
        self.article = article
    }

    func toggleFavorite() {
        if FavoriteManager.shared.isFavorite(article) {
            FavoriteManager.shared.removeFavorite(article)
        } else {
            FavoriteManager.shared.addFavorite(article)
        }
    }

    func isFavorite() -> Bool {
        return FavoriteManager.shared.isFavorite(article)
    }
}
