

// Managers/FavoriteManager.swift

import Foundation

class FavoriteManager {
    static let shared = FavoriteManager()
    private let userDefaults = UserDefaults.standard
    private let favoritesKey = "favoriteArticles"
    private var favorites: [Article] = []

    private init() {
        loadFavorites()
    }

    private func loadFavorites() {
        if let data = userDefaults.data(forKey: favoritesKey),
           let savedFavorites = try? JSONDecoder().decode([Article].self, from: data) {
            favorites = savedFavorites
        }
    }

    private func saveFavorites() {
        if let data = try? JSONEncoder().encode(favorites) {
            userDefaults.set(data, forKey: favoritesKey)
        }
    }

    func addFavorite(_ article: Article) {
        guard let link = article.link else { return } // Проверяем, что link не nil
        if !favorites.contains(where: { $0.link == link }) {
            favorites.append(article)
            saveFavorites()
        }
    }

    func removeFavorite(_ article: Article) {
        guard let link = article.link else { return }
        favorites.removeAll { $0.link == link }
        saveFavorites()
    }

    func isFavorite(_ article: Article) -> Bool {
        guard let link = article.link else { return false }
        return favorites.contains { $0.link == link }
    }

    func getFavorites() -> [Article] {
        return favorites
    }
}
