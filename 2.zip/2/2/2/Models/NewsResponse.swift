import Foundation



struct NewsResponse: Codable {
    let status: String?
    let totalResults: Int?
    let results: [Article]?
    let nextPage: String?
}
