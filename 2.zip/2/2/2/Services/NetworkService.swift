
// Services/NetworkService.swift

import Foundation

enum NetworkError: Error {
    case invalidURL
    case noData
    case unknown
}


class NetworkService {
    static let shared = NetworkService()
    
    private let apiKey = "pub_551426120912a4ad09123075121541c37b8de"
    private let baseURL = "https://newsdata.io/api/1"
    
    private init() {}

    func fetchTopHeadlines(nextPage: String?, completion: @escaping (Result<(articles: [Article], nextPage: String?), Error>) -> Void) {
        var urlString = "\(baseURL)/news?country=us&language=en&apikey=\(apiKey)"
        if let nextPage = nextPage {
            urlString += "&page=\(nextPage)"
        }
        // Добавьте дополнительные параметры, если они необходимы
        guard let url = URL(string: urlString) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(NetworkError.noData))
                return
            }

            // Для отладки: выводим сырой JSON-ответ
            if let jsonString = String(data: data, encoding: .utf8) {
                print("API Response: \(jsonString)")
            }

            do {
                let decoder = JSONDecoder()
                let newsResponse = try decoder.decode(NewsResponse.self, from: data)

                // После успешного получения данных
                if newsResponse.status == "success", let articles = newsResponse.results {
                    for article in articles {
                        print("Заголовок: \(article.title ?? "Нет заголовка")")
                        print("URL изображения: \(article.imageUrl ?? "Нет URL изображения")")
                    }
                    completion(.success((articles: articles, nextPage: newsResponse.nextPage)))
                }
            } catch {
                completion(.failure(error))
            }
        }
        task.resume()
    }
}

