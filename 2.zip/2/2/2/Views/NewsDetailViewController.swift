


// Views/NewsDetailViewController.swift

import UIKit
import SafariServices

class NewsDetailViewController: UIViewController {
    private let viewModel: NewsDetailViewModel

    private let scrollView = UIScrollView()
    private let contentView = UIView()
    private let titleLabel = UILabel()
    private let creatorLabel = UILabel()
    private let imageView = UIImageView()
    private let descriptionLabel = UILabel()
    private let favoriteButton = UIButton(type: .system)
    private let readMoreButton = UIButton(type: .system)

    init(viewModel: NewsDetailViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        configure()
    }

    private func setupUI() {
        view.backgroundColor = .systemBackground

        // Добавляем scrollView и contentView
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        // Добавляем все UI-элементы в contentView
        [titleLabel, creatorLabel, imageView, descriptionLabel, favoriteButton, readMoreButton].forEach {
            contentView.addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
        }

        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false

        // Устанавливаем констрейнты
        NSLayoutConstraint.activate([
            // Констрейнты для scrollView
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            // Констрейнты для contentView
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),

            // Констрейнты для titleLabel
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16),
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            // Констрейнты для creatorLabel
            creatorLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            creatorLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            creatorLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            // Констрейнты для imageView
            imageView.topAnchor.constraint(equalTo: creatorLabel.bottomAnchor, constant: 16),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.heightAnchor.constraint(equalToConstant: 200),

            // Констрейнты для descriptionLabel
            descriptionLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 16),
            descriptionLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            descriptionLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),

            // Констрейнты для favoriteButton
            favoriteButton.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 16),
            favoriteButton.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),

            // Констрейнты для readMoreButton
            readMoreButton.topAnchor.constraint(equalTo: favoriteButton.bottomAnchor, constant: 16),
            readMoreButton.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            readMoreButton.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16)
        ])

        // Настройка UI элементов
        titleLabel.font = UIFont.boldSystemFont(ofSize: 24)
        titleLabel.numberOfLines = 0

        creatorLabel.font = UIFont.systemFont(ofSize: 16)
        creatorLabel.textColor = .secondaryLabel

        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true

        descriptionLabel.font = UIFont.systemFont(ofSize: 18)
        descriptionLabel.numberOfLines = 0

        favoriteButton.setTitleColor(.systemBlue, for: .normal)
        favoriteButton.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        favoriteButton.addTarget(self, action: #selector(toggleFavorite), for: .touchUpInside)

        readMoreButton.setTitle("Read Full Article", for: .normal)
        readMoreButton.setTitleColor(.systemBlue, for: .normal)
        readMoreButton.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        readMoreButton.addTarget(self, action: #selector(openFullArticle), for: .touchUpInside)
    }

    private func configure() {
        let article = viewModel.article

        titleLabel.text = article.title
        creatorLabel.text = "By \(article.creator?.first ?? "Unknown")"
        descriptionLabel.text = article.description ?? "No description available."

        updateFavoriteButtonTitle()

        if let imageUrl = article.imageUrl, let url = URL(string: imageUrl) {
            imageView.load(url: url)
        } else {
            imageView.image = UIImage(systemName: "photo")
        }
    }

    private func updateFavoriteButtonTitle() {
        let title = viewModel.isFavorite() ? "Remove from Favorites" : "Add to Favorites"
        favoriteButton.setTitle(title, for: .normal)
    }

    @objc private func toggleFavorite() {
        viewModel.toggleFavorite()
        updateFavoriteButtonTitle()
    }

    @objc private func openFullArticle() {
        if let link = viewModel.article.link, let url = URL(string: link) {
            let safariVC = SFSafariViewController(url: url)
            present(safariVC, animated: true)
        } else {
            // Если ссылка недоступна, можно показать алерт
            let alert = UIAlertController(title: "Error", message: "No URL available for this article.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
}
